# BubblesOS

A playful, browser-based operating-system simulation built as a single HTML page.

## Run it

Open `index.html` in a modern web browser. No build step is required.

## Features

- Desktop, taskbar, clock, start menu, and draggable app windows
- Built-in apps such as Explorer, Settings, Notes, Calculator, Paint, and Bubbles
- Themes, volume controls, notifications, and sound effects
- Browser-local virtual files and settings
- Simulated Recovery Bubbles, BubblesPE, command prompt, BIOS/UEFI, diagnostics, and startup repair
- Small easter eggs

## Important note

BubblesOS is a browser-based simulation, not a real operating system. Recovery, BIOS/UEFI, diagnostics, and repair tools are simulated and do not repair or modify your computer. Virtual files and settings are stored in the browser.

## Version

Prototype version: **0.1**
