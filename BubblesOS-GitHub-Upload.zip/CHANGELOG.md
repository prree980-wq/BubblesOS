# Changelog

## 0.1 — Prototype

- Added a desktop and taskbar with a start menu and clock.
- Added built-in apps and draggable windows.
- Added themes, sound effects, notifications, and browser-local virtual files.
- Added simulated Recovery Bubbles / BubblesPE utilities and easter eggs.
